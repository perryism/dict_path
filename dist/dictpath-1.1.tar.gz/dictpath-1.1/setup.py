from distutils.core import setup

setup(name='dictpath',
      version='1.1',
      py_modules=['dictpath'],
      )
